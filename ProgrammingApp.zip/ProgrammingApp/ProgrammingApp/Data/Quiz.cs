namespace ProgrammingApp.Data
{
    public class Quiz
    {
        public string Question { get; set; }

        public bool Answer { get; set; }

        public bool Correct { get; set; }

       public int Points { get; set; }

       

    }
}