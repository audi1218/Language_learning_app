using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;



namespace ProgrammingApp.Data
{
    public class QuizService
    {


        private readonly HttpClient _httpClient;

        public QuizService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<string> GetDataFromApi()
        {
            var response = await _httpClient.GetAsync("https://opentdb.com/api.php?amount=10&category=18&type=boolean");
            string json = await response.Content.ReadAsStringAsync();
            var deserializedQuiz = JsonConvert.DeserializeObject<Quiz[]>(json);


            return json;

         
        }



    }
    
}