﻿namespace ProgrammingApp.Data
{
    public class UserInput
    {
        public string Input;

        
    }
}
