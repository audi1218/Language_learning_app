﻿namespace ProgrammingApp.Data
{
    public class UserInput : IComparable<Questions>
    {
        public string Input { get; set; }

      
        public int CompareTo(Questions other)
        {
            return string.Compare(this.Input, other.Answer, StringComparison.OrdinalIgnoreCase);
        }

    }
}
