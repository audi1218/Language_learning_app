﻿using ProgrammingApp;
namespace ProgrammingApp.Data
{
    public class ProgressService
    {
        public int TotalPoints { get; set; }
        public int EarnedPoints { get; set; }

        public int Levels { get; set; } 

        public int QuestionsAnswered { get; set; }
        

            public event Action<int> OnProgressUpdated;

            public void UpdateProgress(int earnedPoints)
            {
                OnProgressUpdated?.Invoke(earnedPoints);
            }
        
    }
}
