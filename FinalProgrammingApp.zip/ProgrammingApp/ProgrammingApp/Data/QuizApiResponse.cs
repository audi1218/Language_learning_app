﻿namespace ProgrammingApp.Data
{
    
        public class QuizApiResponse
        {
            public int ResponseCode { get; set; }
            public List<QuizApiResult> Results { get; set; }
        }

    
}
