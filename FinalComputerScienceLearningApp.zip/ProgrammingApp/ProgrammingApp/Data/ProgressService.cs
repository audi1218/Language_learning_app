﻿using ProgrammingApp;
namespace ProgrammingApp.Data
{
    public class ProgressService
    {
        public int TotalPoints { get; set; }
        public int EarnedPoints { get; set; }

        public int Levels { get; set; } 

        public int QuestionsAnswered { get; set; }
        
        // event that signals progress has been updated
            public event Action<int> OnProgressUpdated;

        //triggers event if a method is subscribed that takes an int parameter is void
            public void UpdateProgress(int earnedPoints)
            {
                OnProgressUpdated?.Invoke(earnedPoints);
            }
        
    }
}
