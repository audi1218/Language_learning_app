﻿using ProgrammingApp;

namespace ProgrammingApp.Data
{
    public class Questions
    {
        public string Question { get; set; }
        public string Answer { get; set; }
        public override string ToString()
        {
            return Question;
        }
    }
}
