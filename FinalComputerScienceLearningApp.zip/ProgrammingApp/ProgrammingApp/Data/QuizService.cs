using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;



namespace ProgrammingApp.Data
{
    public class QuizService
    {


        private readonly HttpClient _httpClient;

        public QuizService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // generates the quiz
        public async Task<Quiz[]> GetDataFromApi()
        {
            const int maxRetries = 3;
            int retries = 0;

            while (retries < maxRetries)
            {
                var response = await _httpClient.GetAsync("https://opentdb.com/api.php?amount=10&category=18&type=boolean");

                if (response.IsSuccessStatusCode)
                {
                    string json = await response.Content.ReadAsStringAsync();

                    if (!string.IsNullOrEmpty(json))
                    {
                        // Deserialize the JSON into an instance of QuizApiResponse
                        var apiResponse = JsonConvert.DeserializeObject<QuizApiResponse>(json);

                        // Extract the Results property from the API response
                        var quizResults = apiResponse?.Results;

                        if (quizResults != null && quizResults.Any())
                        {
                            // Convert the QuizApiResult objects to Quiz objects
                            var quizzes = quizResults.Select(result => new Quiz
                            {
                                Type = result.Type,
                                Difficulty = result.Difficulty,
                                Category = result.Category,
                                Question = result.Question,
                                Correct_Answer = result.Correct_Answer,
                                Incorrect_Answers = result.IncorrectAnswers
                            }).ToArray();

                            return quizzes;
                        }
                    }
                    else
                    {
                        // Handle the case where the API response is empty
                        throw new InvalidOperationException("API response is empty.");
                    }
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                {
                    // Implement a delay before retrying (you can adjust the duration)
                    await Task.Delay(TimeSpan.FromSeconds(5));
                    retries++;
                }
                else
                {
                    // Handle other non-success status codes
                    throw new HttpRequestException($"API request failed with status code {response.StatusCode}");
                }
            }

            // If we reach this point, it means the maximum number of retries has been reached
            throw new HttpRequestException($"API request failed even after {maxRetries} retries.");
        }
       
      
    }
}
